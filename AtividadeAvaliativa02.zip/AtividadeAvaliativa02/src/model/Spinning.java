package model;

import enums.StatusAtividade;
import interfaces.ControladorPresenca;

public class Spinning extends Atividade implements ControladorPresenca {
    private int quantidadeBicicletas;
    private double frequencia;
    
    public Spinning(String nome, String horario, int duracaoAula, int quantidadeMaximaParticipantes, double valorMensal,
            StatusAtividade status, int quantidadeBicicletas, double frequencia) {
        super(nome, horario, duracaoAula, quantidadeMaximaParticipantes, valorMensal, status);
        this.quantidadeBicicletas = quantidadeBicicletas;
        this.frequencia = frequencia;
    }

    public int getQuantidadeBicicletas() {
        return quantidadeBicicletas;
    }

    public void setQuantidadeBicicletas(int quantidadeBicicletas) {
        this.quantidadeBicicletas = quantidadeBicicletas;
    }

    public double getFrequencia() {
        return frequencia;
    }

    public void setFrequencia(double frequencia) {
        this.frequencia = frequencia;
    }

    public boolean atividadeColetiva() {
        return true;
    }

    public void exibirDetalhes() {
        System.out.println("Spinning [quantidadeBicicletas=" + quantidadeBicicletas + ", frequencia=" + frequencia
                + ", getQuantidadeBicicletas()=" + getQuantidadeBicicletas() + ", getFrequencia()=" + getFrequencia()
                + ", getNome()=" + getNome() + ", atividadeColetiva()=" + atividadeColetiva() + ", getHorario()="
                + getHorario() + ", getDuracaoAula()=" + getDuracaoAula() + ", getQuantidadeMaximaParticipantes()="
                + getQuantidadeMaximaParticipantes() + ", getValorMensal()=" + getValorMensal() + ", getStatus()="
                + getStatus() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
                + super.toString() + "]");
    }

    public void registrarPresenca(String nome) {
        System.out.println("Presença registrada para " + nome);
    }
}
