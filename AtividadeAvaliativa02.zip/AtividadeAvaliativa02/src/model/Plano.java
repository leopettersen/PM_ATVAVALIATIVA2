/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import enums.StatusPlano;

/**
 *
 * @author glbra
 */
public abstract class Plano {

    private String nome;
    private double valorMensal;
    private int quantidadeMaximaAtividades;
    private StatusPlano status;
    private int quantidadeAtividades;

    public Plano(String nome, double valorMensal, int quantidadeMaximaAtividades, StatusPlano status,
            int quantidadeAtividades) {
        this.nome = nome;
        this.valorMensal = valorMensal;
        this.quantidadeMaximaAtividades = quantidadeMaximaAtividades;
        this.status = status;
        this.quantidadeAtividades = quantidadeAtividades;
    }

    public int getQuantidadeAtividades() {
        return quantidadeAtividades;
    }

    public void setQuantidadeAtividades(int quantidadeAtividades) {
        this.quantidadeAtividades = quantidadeAtividades;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getValorMensal() {
        return valorMensal;
    }

    public void setValorMensal(double valorMensal) {
        this.valorMensal = valorMensal;
    }

    public int getQuantidadeMaximaAtividades() {
        return quantidadeMaximaAtividades;
    }

    public void setQuantidadeMaximaAtividades(int quantidadeMaximaAtividades) {
        this.quantidadeMaximaAtividades = quantidadeMaximaAtividades;
    }

    public StatusPlano getStatus() {
        return status;
    }

    public void setStatus(StatusPlano status) {
        this.status = status;
    }

    public abstract void exibirDetalhes();

    public abstract boolean permiteAtividadeColetiva();

    @Override
    public String toString() {
        return "Plano [nome=" + nome + ", valorMensal=" + valorMensal + ", quantidadeMaximaAtividades="
                + quantidadeMaximaAtividades + ", status=" + status + ", quantidadeAtividades=" + quantidadeAtividades
                + ", getQuantidadeAtividades()=" + getQuantidadeAtividades() + ", getNome()=" + getNome()
                + ", getValorMensal()=" + getValorMensal() + ", getQuantidadeMaximaAtividades()="
                + getQuantidadeMaximaAtividades() + ", getStatus()=" + getStatus() + ", permiteAtividadeColetiva()="
                + permiteAtividadeColetiva() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
                + ", toString()=" + super.toString() + "]";
    }
}
   
