package model;

import enums.StatusAtividade;

public class Musculacao extends Atividade {
    private int quantidadeAparelhos;

    public Musculacao(String nome, String horario, int duracaoAula, int quantidadeMaximaParticipantes,
            double valorMensal, StatusAtividade status, int quantidadeAparelhos) {
        super(nome, horario, duracaoAula, quantidadeMaximaParticipantes, valorMensal, status);
        this.quantidadeAparelhos = quantidadeAparelhos;
    }

    public int getQuantidadeAparelhos() {
        return quantidadeAparelhos;
    }

    public void setQuantidadeAparelhos(int quantidadeAparelhos) {
        this.quantidadeAparelhos = quantidadeAparelhos;
    }

    public boolean atividadeColetiva() {
        return false;
    }

    public void exibirDetalhes() {
        System.out.println("Musculacao [quantidadeAparelhos=" + quantidadeAparelhos + ", getQuantidadeAparelhos()="
                + getQuantidadeAparelhos() + ", atividadeColetiva()=" + atividadeColetiva() + ", getNome()=" + getNome()
                + ", getHorario()=" + getHorario() + ", getDuracaoAula()=" + getDuracaoAula()
                + ", getQuantidadeMaximaParticipantes()=" + getQuantidadeMaximaParticipantes() + ", getValorMensal()="
                + getValorMensal() + ", getStatus()=" + getStatus() + ", getClass()=" + getClass() + ", hashCode()="
                + hashCode() + ", toString()=" + super.toString() + "]");
    }
}
