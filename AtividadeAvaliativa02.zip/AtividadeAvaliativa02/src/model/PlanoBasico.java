package model;

import enums.StatusPlano;
import interfaces.ControladorPresenca;

public class PlanoBasico extends Plano implements ControladorPresenca {

    private final int limiteAcesso = 1;
    private int quantidadeAcessos;

    public int getLimiteAcesso() {
        return limiteAcesso;
    }

    public void exibirDetalhes() {
        System.out.println("PlanoBasico [limiteAcesso=" + limiteAcesso + ", quantidadeAcessos=" + quantidadeAcessos
                + ", getLimiteAcesso()=" + getLimiteAcesso() + ", getQuantidadeAtividades()="
                + getQuantidadeAtividades() + ", getNome()=" + getNome() + ", getValorMensal()=" + getValorMensal()
                + ", permiteAtividadeColetiva()=" + permiteAtividadeColetiva() + ", getQuantidadeMaximaAtividades()="
                + getQuantidadeMaximaAtividades() + ", getStatus()=" + getStatus() + ", getQuantidadeAcessos()="
                + getQuantidadeAcessos() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
                + super.toString() + "]");
    }

    public PlanoBasico(String nome, double valorMensal, int quantidadeMaximaAtividades, StatusPlano status,
            int quantidadeAtividades, int quantidadeAcessos) {
        super(nome, valorMensal, quantidadeMaximaAtividades, status, quantidadeAtividades);
        this.quantidadeAcessos = quantidadeAcessos;
    }

    public boolean permiteAtividadeColetiva() {
        return false;
    }

    public void registrarPresenca(String nome) {
        if (quantidadeAcessos < limiteAcesso) {
            System.out.println("Presença registrada para " + nome);
        }
        else {
            System.out.println(nome + " já acessou a academia hoje");
        }
    }

    public int getQuantidadeAcessos() {
        return quantidadeAcessos;
    }

    public void setQuantidadeAcessos(int quantidadeAcessos) {
        this.quantidadeAcessos = quantidadeAcessos;
    }
}
