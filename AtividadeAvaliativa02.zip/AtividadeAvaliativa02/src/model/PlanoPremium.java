package model;

import enums.StatusPlano;

public class PlanoPremium extends Plano {
    public boolean permiteAtividadeColetiva() {
        return true;
    }

    public void exibirDetalhes() {
        System.out.println("PlanoPremium [limiteAcesso= não possui limite de acesso" + ", permiteAtividadeColetiva()="
                + permiteAtividadeColetiva() + ", getNome()=" + getNome()
                + ", getValorMensal()=" + getValorMensal() + ", getQuantidadeMaximaAtividades()="
                + getQuantidadeMaximaAtividades() + ", getStatus()=" + getStatus() + ", getClass()=" + getClass()
                + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]");
    }

    public PlanoPremium(String nome, double valorMensal, int quantidadeMaximaAtividades, StatusPlano status,
            int quantidadeAtividades) {
        super(nome, valorMensal, quantidadeMaximaAtividades, status, quantidadeAtividades);
    }
}
