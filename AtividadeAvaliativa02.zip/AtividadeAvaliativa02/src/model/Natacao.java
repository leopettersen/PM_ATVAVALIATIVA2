package model;

import enums.StatusAtividade;
import interfaces.Certificavel;

public class Natacao extends Atividade implements Certificavel {
    private double profundidadePiscina;
    private double frequencia;
    
    public Natacao(String nome, String horario, int duracaoAula, int quantidadeMaximaParticipantes, double valorMensal,
            StatusAtividade status, double profundidadePiscina, double frequencia) {
        super(nome, horario, duracaoAula, quantidadeMaximaParticipantes, valorMensal, status);
        this.profundidadePiscina = profundidadePiscina;
        this.frequencia = frequencia;
    }

    public double getProfundidadePiscina() {
        return profundidadePiscina;
    }

    public void setProfundidadePiscina(double profundidadePiscina) {
        this.profundidadePiscina = profundidadePiscina;
    }

    public double getFrequencia() {
        return frequencia;
    }

    public void setFrequencia(double frequencia) {
        this.frequencia = frequencia;
    }

    public boolean atividadeColetiva() {
        return true;
    }

    public void exibirDetalhes() {
        System.out.println("Natacao [profundidadePiscina=" + profundidadePiscina + ", frequencia=" + frequencia
                + ", getProfundidadePiscina()=" + getProfundidadePiscina() + ", getFrequencia()=" + getFrequencia()
                + ", getNome()=" + getNome() + ", atividadeColetiva()=" + atividadeColetiva() + ", getHorario()="
                + getHorario() + ", getDuracaoAula()=" + getDuracaoAula() + ", getQuantidadeMaximaParticipantes()="
                + getQuantidadeMaximaParticipantes() + ", getValorMensal()=" + getValorMensal() + ", getStatus()="
                + getStatus() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
                + super.toString() + "]");
    }

    public void emitirCertificado(String nome) {
        System.out.println("Certificado emitido: " + nome);
    }
}
