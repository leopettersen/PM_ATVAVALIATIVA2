package interfaces;

public interface Certificavel {
    public abstract void emitirCertificado(String nome);
}
