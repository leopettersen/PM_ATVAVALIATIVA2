package interfaces;

public interface ControladorPresenca {
    public abstract void registrarPresenca(String nome);
}
