import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import enums.StatusAtividade;
import enums.StatusPlano;
import model.Atividade;
import model.Musculacao;
import model.Natacao;
import model.Plano;
import model.PlanoBasico;
import model.PlanoPremium;
import model.Spinning;

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Plano plano1 = new PlanoBasico("Glender", 1000, 1, StatusPlano.ATIVO, 0, 0);
        Plano plano2 = new PlanoPremium("Leonardo", 2000, 999, StatusPlano.ATIVO, 0);
        Atividade atv1 = new Natacao("Turma 1 natação", "19:00", 2, 10, 0, StatusAtividade.ATIVA, 2, 3);
        Atividade atv2 = new Musculacao("Musculação", null, 0, 0, 100, StatusAtividade.ATIVA, 0);
        Atividade atv3 = new Spinning("Turma 1 spinnig", "21:00", 1, 5, 500, StatusAtividade.ATIVA, 5, 4);

        List<Plano> planos = new ArrayList<>();
        List<Atividade> atividades = new ArrayList<>();
        planos.add(plano1);
        planos.add(plano2);
        atividades.add(atv1);
        atividades.add(atv2);
        atividades.add(atv3);
        int opc;

        System.out.println();
        System.out.println("MENU");
        System.out.println("1. Associar atividade a um plano");
        System.out.println("2. Exibir todas as atividades cadastradas");
        System.out.println("3. Exibir todos os planos cadastrados");
        System.out.println("4. Exibir apenas planos ativos");
        System.out.println("5. Emitir certificado");
        System.out.println("6. Registrar presença");
        System.out.println("7. Remover atividades inativas");
        System.out.println();
        opc = sc.nextInt();
        sc.nextLine();

        while (opc != 0) {
            if (opc == 1) {
                System.out.println("Digite o nome do Plano que você deseja cadastrar a atividade");
                String n = sc.nextLine();
                for (Plano p : planos) {
                    if (p.getNome().equals(n)) {
                        if (p.getQuantidadeMaximaAtividades() >= p.getQuantidadeAtividades()) {
                            System.out.println("Quantidade máxima de atividades cadastradas");
                            break;
                        }
                        System.out.println("Digite o nome da atividade que você quer cadastrar");
                        n = sc.nextLine();
                        for (Atividade a : atividades) {
                            if (a.getNome().equals(n)) {
                                System.out.println("Atividade cadastrada");
                                p.setQuantidadeAtividades(p.getQuantidadeAtividades() + 1);
                                break;
                            }
                            System.out.println("Atividade não existe");
                            break;
                        }
                    }
                    System.out.println("Plano não existe");
                    break;
                }
            } else if (opc == 2) {
                for (Atividade a : atividades) {
                    a.exibirDetalhes();
                }
            } else if (opc == 3) {
                for (Plano p : planos) {
                    p.exibirDetalhes();
                }
            } else if (opc == 4) {
                for (Plano p : planos) {
                    if (p.getStatus() == StatusPlano.ATIVO) {
                        p.exibirDetalhes();
                    }
                }
            } else if (opc == 5) {
                for (Atividade a : atividades) {
                    if (a instanceof Natacao) {
                        ((Natacao)a).emitirCertificado("Certificado de Natação");
                    }
                }
            } else if (opc == 6) {
                System.out.println("Digite o nome de quem regitrar presença");
                String n = sc.nextLine();
                for (Plano p : planos) {
                    if (p.getNome().equals(n)) {
                        for (Atividade a : atividades) {
                            if (a instanceof Spinning) {
                                ((Spinning)a).registrarPresenca(n);
                    }
                }
                    }
                }
            } else {
                for (Atividade a : atividades) {
                    if (a.getStatus() == StatusAtividade.INATIVA) {
                        atividades.remove(a);
                    }
                }
            }
        }

        if (opc > 0 && opc <= 7) {
                System.out.println();
                System.out.println("MENU");
                System.out.println("1. Associar atividade a um plano");
                System.out.println("2. Exibir todas as atividades cadastradas");
                System.out.println("3. Exibir todos os planos cadastrados");
                System.out.println("4. Exibir apenas planos ativos");
                System.out.println("5. Emitir certificado");
                System.out.println("6. Registrar presença");
                System.out.println("7. Remover atividades inativas");
                System.out.println();
                opc = sc.nextInt();
                sc.nextLine();
            } else {
                System.out.println("Opção invalida");
            }
            sc.close();
    }
}
